<?php
include_once __DIR__ . '/auth.php';
include_once __DIR__ . '/authenticated.php';