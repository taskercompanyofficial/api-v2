<?php

use App\Http\Controllers\Authenticated\CRM\ProductsController;
use App\Http\Controllers\Authenticated\CRM\ServicesController;
use App\Http\Controllers\Authenticated\CRM\StoreItemController;
use App\Http\Controllers\Authenticated\CRM\StoreItemInstanceController;
use Illuminate\Support\Facades\Route;

Route::group(['prefix' => 'crm'], function () {
    Route::group(['middleware' => ['auth:sanctum']], function () {
        Route::apiResource('/store-items', StoreItemController::class);
        Route::apiResource('/store-item-instances', StoreItemInstanceController::class);
        Route::apiResource('/products', ProductsController::class);
        Route::apiResource('/services', ServicesController::class);
    });
});
